# Gestion Financière BHDS — Application PC (Electron)

Structure du dépôt (comme votre exemple) :

```
.github/workflows/   → build.yml (compilation automatique sur GitHub)
.gitignore
index.html            → votre application (Gestion_financière_v5_8.html)
main.js                → point d'entrée Electron
package.json
preload.js              → pont sécurisé Electron ↔ page web
build/icon.png          → (optionnel) logo de l'app, à ajouter vous-même
```

## 🚀 Compiler via GitHub (recommandé, depuis le téléphone)

### 1. Créer le dépôt et envoyer les fichiers

- Créez un dépôt sur https://github.com (public ou privé)
- Uploadez TOUT le contenu de ce dossier (bouton "uploading an existing
  file" ou "Add file" → "Upload files"), en conservant les noms et
  l'arborescence : `.github/workflows/build.yml` doit être visible dans le
  dépôt après l'envoi.

### 2. Créer une version (tag) pour déclencher la compilation

Ce workflow se déclenche quand vous créez un **tag** de version (ex: `v1.0.0`),
exactement comme dans le dépôt que vous m'avez montré (qui a 4 tags).

Depuis le téléphone, le plus simple :
1. Aller dans l'onglet **Releases** du dépôt (ou "Tags" → "Create a new
   release")
2. Cliquer **"Create a new release"**
3. Dans "Choose a tag", taper `v1.0.0` puis **"Create new tag"**
4. Titre : `Version 1.0.0`, puis **"Publish release"**

→ Cela déclenche automatiquement le workflow. Au bout de quelques minutes,
GitHub attache lui-même le fichier `.exe` compilé directement sur cette
Release (onglet **Releases**, en dessous de la description).

Vous pouvez aussi déclencher une compilation sans créer de tag, juste pour
tester : onglet **Actions** → "Build & Release Windows Installer" →
**Run workflow**. Dans ce cas le `.exe` sera disponible dans **Artifacts**
(mais pas attaché à une Release, puisqu'il n'y a pas de tag).

### 3. Mettre à jour l'application plus tard

- Remplacez `index.html` par la nouvelle version sur GitHub
- Créez un nouveau tag (`v1.1.0`, `v1.2.0`, ...) → une nouvelle Release avec
  le nouvel installateur est générée automatiquement

## Notes importantes

- **Données** : `localStorage`, propre à chaque PC (pas de synchronisation
  entre postes). Dites-moi si vous voulez passer à Firebase pour partager les
  données entre plusieurs ordinateurs.
- **Icône** : déposez un `icon.png` (512x512 px minimum) dans `build/` avant
  de créer un tag, pour que l'app ait le logo Collection BHDS.
- **Liens WhatsApp** : s'ouvrent dans le navigateur par défaut du PC.

## Alternative : compiler soi-même sur un PC (sans GitHub)

```
npm install
npm start          # tester l'app
npm run build:win  # génère dist/*.exe
```
Nécessite Node.js installé (https://nodejs.org).
