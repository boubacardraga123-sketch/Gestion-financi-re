const { app, BrowserWindow, shell, Menu } = require('electron');
const path = require('path');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1000,
    minHeight: 650,
    backgroundColor: '#f0f4f8',
    icon: path.join(__dirname, 'build', 'icon.png'),
    autoHideMenuBar: true, // cache la barre de menu (File/Edit/View...) pour un look "app"
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));

  // Les liens externes (ex: WhatsApp, factures, etc.) s'ouvrent dans le
  // navigateur par défaut plutôt que dans une nouvelle fenêtre Electron.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  // Optionnel: décommenter pour déboguer
  // mainWindow.webContents.openDevTools();
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(null); // supprime complètement la barre de menu
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
