// preload.js
// Ce fichier s'exécute avant le chargement de la page, avec un accès limité
// et sécurisé à Node.js. Il sert de "pont" entre l'app web (index.html) et
// le système si un jour vous avez besoin de fonctions natives
// (ex: impression directe, sauvegarde de fichiers sur le disque, etc.).
//
// Pour l'instant il n'expose rien, l'application fonctionne uniquement en
// HTML/JS classique avec localStorage.

const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('appInfo', {
  platform: process.platform,
  version: process.env.npm_package_version || '1.0.0'
});
