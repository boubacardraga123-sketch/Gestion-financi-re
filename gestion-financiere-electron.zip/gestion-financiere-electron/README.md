# Gestion Financière BHDS — Setup Electron (build via GitHub)

Ce dossier transforme ton app `Gestion_financière_v5_8.html` en application Windows (.exe), buildée automatiquement par GitHub Actions — pas besoin d'un PC Windows pour compiler.

## Structure

```
gestion-financiere-electron/
├── app/
│   └── index.html          ← ton app (copie de Gestion_financière_v5_8.html)
├── build/                  ← (optionnel) mets ici icon.ico pour une icône personnalisée
├── .github/workflows/
│   └── build.yml           ← build automatique GitHub Actions
├── main.js                 ← point d'entrée Electron
├── package.json
└── .gitignore
```

## Étapes pour publier sur GitHub et lancer le build

### 1. Créer le dépôt GitHub
Crée un nouveau dépôt (ex: `gestion-financiere-bhds-desktop`), **privé** de préférence si l'app contient des données sensibles.

### 2. Pousser ce projet
Depuis ce dossier, en local (terminal) :
```bash
git init
git add .
git commit -m "Setup Electron - Gestion Financière BHDS"
git branch -M main
git remote add origin https://github.com/TON-COMPTE/gestion-financiere-bhds-desktop.git
git push -u origin main
```

### 3. Déclencher le build
Deux façons :

**A. Manuellement (recommandé pour tester)**
- Va sur GitHub → onglet **Actions** → workflow **"Build Windows App"** → bouton **"Run workflow"**.

**B. Automatiquement via un tag de version**
```bash
git tag v5.8.0
git push origin v5.8.0
```
→ Ça déclenche le build ET crée une Release GitHub avec le `.exe` attaché.

### 4. Récupérer le fichier .exe
- Si build manuel : va dans Actions → le run terminé → section **Artifacts** en bas → télécharge `GestionFinanciereBHDS-Windows`.
- Si via tag : va dans **Releases** → télécharge le `.exe` directement.

Tu obtiendras 2 fichiers :
- `Gestion Financière BHDS Setup X.X.X.exe` → installeur classique (raccourci bureau + menu démarrer)
- `Gestion Financière BHDS X.X.X.exe` (portable) → à lancer directement, sans installation

## Mettre à jour l'app plus tard

Quand tu modifies `Gestion_financière_v5_8.html` :
1. Remplace `app/index.html` par la nouvelle version.
2. Augmente le `version` dans `package.json` (ex: `5.9.0`).
3. Commit + push + nouveau tag → nouveau build automatique.

## Ajouter une icône personnalisée (optionnel)
1. Crée un fichier `icon.ico` (256x256 recommandé — tu peux convertir un PNG sur convertio.co ou icoconvert.com).
2. Place-le dans `build/icon.ico`.
3. Dans `package.json`, sous `"win"`, ajoute `"icon": "build/icon.ico"`.

## Tester en local avant de publier (optionnel)
Si tu as Node.js installé sur ton PC :
```bash
npm install
npm start
```
