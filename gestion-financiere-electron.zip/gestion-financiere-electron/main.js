const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1000,
    minHeight: 700,
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    },
    autoHideMenuBar: true, // cache le menu par défaut (File/Edit/View...)
    show: false,
  });

  mainWindow.loadFile(path.join(__dirname, 'app', 'index.html'));

  // Affiche la fenêtre seulement quand tout est chargé (évite le flash blanc)
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // Ouvre les liens externes (http/https) dans le navigateur système, pas dans l'app
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http')) {
      shell.openExternal(url);
      return { action: 'deny' };
    }
    return { action: 'allow' };
  });

  // Menu minimal (juste Quitter + Recharger, utile en cas de bug)
  const menu = Menu.buildFromTemplate([
    {
      label: 'Fichier',
      submenu: [
        { role: 'reload', label: 'Recharger' },
        { role: 'toggleDevTools', label: 'Outils développeur' },
        { type: 'separator' },
        { role: 'quit', label: 'Quitter' },
      ],
    },
  ]);
  Menu.setApplicationMenu(menu);
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
